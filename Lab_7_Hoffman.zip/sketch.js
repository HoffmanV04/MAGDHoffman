var v = 0
var x = 0
var y = 0
var h = 380
var b, a

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
  rectMode(CORNERS)
  

}

function draw() {
  background(25);
  for (var x = 50; x <= 400; x += 60) {
    flake(x,y)}
  y+=2
  v++;
  if(y>h){
    y = 0;
    h-=2}
    rect(0,h,400,400)
push()
  scale(2)
cloud(100,25) 
pop()
  push()
  scale(3)
cloud(125,10) 
pop()
  push()
  scale(3)
cloud(30,20) 
pop()
  push()
  scale(2)
cloud(30,5) 
pop()
}

function flake(x, y){
  push()
  translate(x,y)
  stroke(255)
  strokeWeight(5)
  strokeCap(ROUND)
  scale(0.2)
  rotate(v);
  push()
  for(var r = 0;r < 360;r += 45){
    rotate(r)
    line(0,0,0,-60)
    line(0,-35,15,-50)
    line(0,-20,12,-30)
    line(0,-35,-15,-50)
    line(0,-20,-12,-30)
  }
  pop()

 pop()
}


function cloud(a, b){
  push()
  translate(a,b)
  fill(200)
  noStroke()
  ellipse(0,0,50,20)
  ellipse(10,10,50,20)
  ellipse(-20,10,50,20)
  ellipse(-35,-5,50,20)
  pop()
}