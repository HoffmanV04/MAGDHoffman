var h = []
var j = []
var l = []
var a = []
var b = []
var num = 3

function setup() {
  createCanvas(400, 400);
  colorMode(RGB,400,400,400,1)
  frameRate(2)
  for(i=0; i<400; i+=40){
  h[i] = random (-2000,0)  
  }
for(k=0; k<400; k+=40){
  j[k] = random (-2000,0)  
  }
for(m=0; m<400; m+=40){
  l[m] = random (-2000,0)  
  }

for (var c = 0; c < 3; c++) {
  a[c] = 0;
  b[c] = 0;
	}  
}

function draw() {
background(50);
fill(255,0,0)
stroke(0)
  
//Red Pieces  
for(var i=0; i<400; i+=40){
   var x = i;
    h[i] += 20;
  rect(x,h[i],20,20)
  rect(x,h[i]+20,20,20)
  rect(x+20,h[i]+20,20,20);
  rect(x,h[i]+40,20,20)}
  
//Green Pieces
for(var k=0; k<400; k+=40){
  fill(0,255,0)
  var x = k;
  j[k] += 20;
  rect(x,j[k],20,20)
  rect(x,j[k]+20,20,20)
  rect(x,j[k]+40,20,20)
  rect(x,j[k]+60,20,20)} 
  
for(var m=0; m<400; m+=40){
  fill(20,20,255)
  var x = m;
  l[m] += 20;
  rect(x,l[m],20,20)
  rect(x,l[m]-20,20,20)
  rect(x-20,l[m]-20,20,20)
  rect(x+20,l[m],20,20)} 
  
  
for(var z = 0; z < 400; z+=20){line(z,0,z,400)}
 // print(y.length);
 // print(f.length);
for(c = 3; c > 0; c--){
  a[c] = a[c-1]
  b[c] = b[c-1]
}
  
a[0] = mouseX
b[0] = mouseY
  
for(c=0; c<3; c++){
  fill(200/c,200/c,0)
  ellipse(a[c],b[c],20,20)
}
print(a.length)
}