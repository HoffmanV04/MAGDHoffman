function setup() {
  // put setup code here
 
}

function draw() {

    // put draw code here
}
